package second;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
public class Three extends JFrame implements ActionListener {
	JButton que;
	JButton dl;
	JButton submit;
	JButton cancel;
	JTextField tf_que;
	JLabel l_que;
	JButton viewResults; 
	JTextField ans;
	JLabel sno1;
	JLabel sno2;
	JLabel sno3;
	JLabel sno4;
	JLabel an;
	JTextField option1;
	JTextField option2;
	JTextField option3;
	JTextField option4;
	public Three() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setTitle("Admin - Questions adding page");
		ans = new JTextField();
		an = new JLabel("Answer -->");
		dl = new JButton("Refresh DB");
		que = new JButton("Add Question");
		submit = new JButton("Submit");
		cancel = new JButton("Cancel");
		tf_que = new JTextField();
		l_que = new JLabel("Post Question");
		option1 = new JTextField();
		option2 = new JTextField();
		viewResults = new JButton("View Results"); // Added JButton for viewing results
		option3 = new JTextField();
		option4 = new JTextField();
		sno1 = new JLabel("1.");
		sno2 = new JLabel("2.");
		sno3 = new JLabel("3.");
		sno4 = new JLabel("4.");
		an.setBounds(100,370,80,30);
		dl.setBounds(400,350,150,30);
		dl.setBackground(Color.black);
		dl.setForeground(Color.white);
		l_que.setForeground(Color.red);
		l_que.setBounds(100, 20, 150, 30);
		tf_que.setBounds(100, 50, 300, 80);
		que.setBounds(400,300,150,30);
		option1.setBounds(130,150,80,30);
		option2.setBounds(130,200,80,30);
		option3.setBounds(130,250,80,30);
		option4.setBounds(130,300,80,30);
		ans.setBounds(170,370,80,30);
		sno1.setBounds(100,150,80,30);
		sno2.setBounds(100,200,80,30);
		sno3.setBounds(100,250,80,30);
		sno4.setBounds(100,300,80,30);
		que.setBackground(Color.black);
		que.setForeground(Color.white);
		que.addActionListener(this);
		submit.setBounds(420, 450, 100, 30);
		submit.setBackground(Color.black);
		submit.setForeground(Color.white);
		submit.addActionListener(this);
		cancel.setBounds(420,400,100,30);
		cancel.setBackground(Color.black);
		cancel.setForeground(Color.white);
		l_que.setFont(new Font("Courier",Font.BOLD,15));
		cancel.addActionListener(this);
		dl.addActionListener(this);
		viewResults.setBounds(400, 500, 140, 30);
		viewResults.setBackground(Color.black);
		viewResults.setForeground(Color.white);
		viewResults.addActionListener(this); // Added action listener for view results
		add(tf_que);
		add(l_que);
		add(que);
		add(submit);
		add(cancel);
		add(option1);
		add(option2);
		add(option3);
		add(option4);
		add(sno1);
		add(sno2);	
		add(an);
		add(dl);
		add(ans);
		add(sno3);
		add(sno4);
		add(viewResults); // Added view results button
		setLayout(null);
		setSize(600, 600);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	public static void main(String[] args) {
		new Three();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == que) {
			JOptionPane.showMessageDialog(Three.this,
	                "Question added successfully"
	                + " to the database",
	                " ",
	                JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource() == submit) {
			this.dispose();
		}
		if (e.getSource().equals(que)) {
			String question = tf_que.getText().toString();
			String op1 = option1.getText().toString();
			String op2 = option2.getText().toString();
			String op3 = option3.getText().toString();
			String op4 = option4.getText().toString();
			String answer  = ans.getText().toString();
			try{
				Class.forName("com.mysql.cj.jdbc.Driver"); // step1
				String mysqlUrl = "jdbc:mysql://localhost:3306/db1";
				// step2
				Connection con = DriverManager.getConnection(mysqlUrl, "root", "mitsuha");
				// System.out.println("Connection established......");
				// step3
				PreparedStatement ps = con.prepareStatement("insert into db1.question values(?,?,?,?,?,?,?)");
				ps.setInt(1, 0);
				ps.setString(2, question);
				ps.setString(3, op1);
				ps.setString(4, op2);
				ps.setString(5, op3);
				ps.setString(6, op4);
				ps.setString(7, answer);
				// step4
				ps.execute();
				String resetAutoIncrementQuery = "ALTER TABLE question AUTO_INCREMENT = 1";
				PreparedStatement resetAutoIncrementStmt = con.prepareStatement(resetAutoIncrementQuery);
				resetAutoIncrementStmt.executeUpdate();

			
				// Renumber the remaining questions in the database
				String renumberQuery = "SET @row_number = 0";
				PreparedStatement setRowNumberStmt = con.prepareStatement(renumberQuery);
				setRowNumberStmt.executeUpdate();
			
				String updateQuery = "UPDATE question SET qno = @row_number := @row_number + 1 ORDER BY qno";
				PreparedStatement updateStmt = con.prepareStatement(updateQuery);
				updateStmt.executeUpdate();
				// step5
				con.close();
			} catch (Exception ee) {
				ee.printStackTrace();
			}
			
			tf_que.setText("");
			option1.setText("");
			option2.setText("");
			option3.setText("");
			option4.setText("");
			ans.setText("");
		}if(e.getSource() == cancel) {
			JOptionPane.showMessageDialog(Three.this,
	                "Recent question has been deleted from Database",
	                " ",
	                JOptionPane.INFORMATION_MESSAGE);
			try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // step1
			String mysqlUrl = "jdbc:mysql://localhost:3306/db1";
			// step2
			Connection con = DriverManager.getConnection(mysqlUrl, "root", "mitsuha");
			PreparedStatement ps1 = con.prepareStatement("delete from db1.question ORDER BY qno DESC LIMIT 1");
			ps1.execute();
			String resetAutoIncrementQuery = "ALTER TABLE question AUTO_INCREMENT = 1";
			PreparedStatement resetAutoIncrementStmt = con.prepareStatement(resetAutoIncrementQuery);
			resetAutoIncrementStmt.executeUpdate();

		
			// Renumber the remaining questions in the database
			String renumberQuery = "SET @row_number = 0";
			PreparedStatement setRowNumberStmt = con.prepareStatement(renumberQuery);
			setRowNumberStmt.executeUpdate();
		
			String updateQuery = "UPDATE question SET qno = @row_number := @row_number + 1 ORDER BY qno";
			PreparedStatement updateStmt = con.prepareStatement(updateQuery);
			updateStmt.executeUpdate();
		
			// step5
			con.close();
			}
			catch (Exception ee) {
				ee.printStackTrace();
			}
		}
		if(e.getSource() == dl) {
			JOptionPane.showMessageDialog(Three.this,
	                "All question has been deleted from Database",
	                " ",
	                JOptionPane.INFORMATION_MESSAGE);
			try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // step1
			String mysqlUrl = "jdbc:mysql://localhost:3306/db1";
			// step2
			Connection con = DriverManager.getConnection(mysqlUrl, "root", "mitsuha");
			PreparedStatement ps2 = con.prepareStatement("truncate table db1.question;");
			ps2.execute();
			// step5
			con.close();
			}
			catch (Exception ee) {
				ee.printStackTrace();
			}
		}
		if(e.getSource() == submit) {
			JOptionPane.showMessageDialog(Three.this,
	                "All question has been added to the Database",
	                " ",
	                JOptionPane.INFORMATION_MESSAGE);
			this.dispose();
		}
		if (e.getSource() == viewResults) {
            // Open a new JFrame to show the results using JTable
            JFrame resultFrame = new JFrame("Results");
            resultFrame.setSize(600, 400);
            resultFrame.setLocationRelativeTo(null);

            // Create a JTable and its model
            DefaultTableModel model = new DefaultTableModel();
            JTable table = new JTable(model);
            model.addColumn("ID");
            model.addColumn("Username");
            model.addColumn("Score");

            // Fetch data from MySQL and populate the table
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String mysqlUrl = "jdbc:mysql://localhost:3306/db1";
                Connection con = DriverManager.getConnection(mysqlUrl, "root", "mitsuha");
                PreparedStatement ps = con.prepareStatement("select * from score");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String username = rs.getString("username");
                    int score = rs.getInt("score");
                    model.addRow(new Object[]{id, username, score});
                }
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            // Add the table to the frame
            JScrollPane scrollPane = new JScrollPane(table);
            resultFrame.add(scrollPane, BorderLayout.CENTER);

            resultFrame.setVisible(true);
        }
	}
}