package second;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Zero extends JFrame implements ActionListener {
    JLabel message;
    JButton Admin;
    JButton User;
    JLabel qu;
    JLabel background;

    public Zero() {
        setTitle("Welcome Admin / User");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLayout(null);

        // Load background image
        ImageIcon backgroundImage = new ImageIcon("src\\second\\images\\background.jpg");
        background = new JLabel(backgroundImage);
        background.setBounds(0, 0, 600, 600);
        add(background);

        qu = new JLabel("Are you a user or an admin?");
        qu.setFont(new Font("Courier", Font.BOLD, 15));
        qu.setBounds(30, 50, 300, 100);
        background.add(qu);

        message = new JLabel("QUIZZY");
        message.setFont(new Font("Serif", Font.ITALIC, 35));
        message.setBounds(230, 20, 300, 40);
        background.add(message);

        Admin = new JButton("ADMIN");
        Admin.setBounds(360, 85, 100, 30);
        Admin.setForeground(Color.white);
        Admin.setBackground(Color.black);
        Admin.addActionListener(this);
        background.add(Admin);

        User = new JButton("USER");
        User.setBounds(470, 85, 100, 30);
        User.setForeground(Color.white);
        User.setBackground(Color.black);
        User.addActionListener(this);
        background.add(User);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        Zero ze = new Zero();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Admin) {
            this.dispose();
            new admin_login();
        }
        if (e.getSource() == User) {
            dispose();
            new One();
        }
    }
}