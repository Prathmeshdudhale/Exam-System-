package second;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class userque1 extends JFrame implements ActionListener {
    JButton start;
    JLabel heading;
    JLabel heading2;
    JButton next;
    JButton submit;
    JLabel que;
    JLabel op1;
    JLabel answ;

    JLabel qu1;
    JLabel qu2;
    JLabel qu3;
    JLabel qu4;
    JTextField answe;
    JLabel op2;
    JLabel op3;
    JLabel op4;
    JLabel quest;
    JPanel questionPanel;
    String res6 = null;
    String te = null;
    int i = 0;
    int count = 0; 
	int score = 0;
	String mysqlUrl = "jdbc:mysql://localhost:3306/db1";
	String username = "root";
	String password = "mitsuha";
	// To store the score

    public userque1() {
		setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        next = new JButton("Next");
        qu1 = new JLabel("1.");
        qu2 = new JLabel("2.");
        qu3 = new JLabel("3.");
        qu4 = new JLabel("4.");
        answ = new JLabel("Type option here");
        submit = new JButton("Submit");
        submit.setBounds(400, 450, 150, 30);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.white);
        answe = new JTextField();
        answ.setForeground(Color.blue);
        answ.setBounds(100, 370, 80, 30);
        answe.setBounds(190, 370, 80, 30);
        qu1.setBounds(80, 150, 80, 30);
        qu2.setBounds(80, 200, 80, 30);
        qu3.setBounds(80, 250, 80, 30);
        qu4.setBounds(80, 300, 80, 30);
        heading = new JLabel("QUIZZY: Online Quiz");
        heading2 = new JLabel("Click on next to start the quiz");
        quest = new JLabel("Question :");
        quest.setBounds(100, 20, 300, 80);
        quest.setForeground(Color.red);
        heading2.setBounds(180, 100, 300, 100);
        heading2.setFont(new Font("Courier", Font.BOLD, 15));
        heading.setFont(new Font("Courier", Font.BOLD, 30));
        heading.setBounds(130, 80, 300, 40);
        heading.setForeground(Color.black);
        next.setBounds(400, 400, 150, 30);
        submit.addActionListener(this);
        next.addActionListener(this);
        questionPanel = new JPanel() {
            // @Override
            // protected void paintComponent(Graphics g) {
            //     super.paintComponent(g);
            //     ImageIcon imageIcon = new ImageIcon("Quizzy\\src\\second\\images\\background.jpg");
            //     Image image = imageIcon.getImage();
            //     g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            // }
        };
        questionPanel.setLayout(null);
        questionPanel.setBounds(0, 0, 600, 600);
		questionPanel.setBackground(new Color(135, 206, 235));
        add(questionPanel);
        add(next);

        questionPanel.add(heading);
        questionPanel.add(heading2);

        setLayout(null);
        setSize(600, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        userque1 u = new userque1();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (te != null && te.equalsIgnoreCase(res6)) {
            score++;
        }
        

        if (e.getSource() == next) {
			Connection con;
			try {
				con = DriverManager.getConnection(mysqlUrl, username, password);
				java.sql.Statement stmt;
				stmt = con.createStatement();
				String query = "select count(*) from question";
		
				ResultSet rs = stmt.executeQuery(query);
				rs.next();
				int totalQuestions = rs.getInt(1); // Get total number of questions
		
				if (i < totalQuestions) { // Ensure i is less than total questions
					i++; // Increment i only if there are more questions
				}
                String answer = "select solution from question where qno='" + i + "' ";
                ResultSet rs6 = stmt.executeQuery(answer);
                rs6.next();
                res6 = rs6.getString(1);
                te = answe.getText().trim();

                String query1 = "select Question from question where qno='" + i + "' ";
                ResultSet rs1 = stmt.executeQuery(query1);
                rs1.next();
                String res = rs1.getString(1);
                que = new JLabel();
                que.setText(res);
                que.setVisible(true);
                que.setBounds(100, 50, 300, 80);
                questionPanel.add(que);

                String query2 = "select op1 from question where qno='" + i + "' ";
                ResultSet rs2 = stmt.executeQuery(query2);
                rs2.next();
                String res2 = rs2.getString(1);
                op1 = new JLabel();
                op1.setText(res2);
                op1.setVisible(true);
                op1.setBounds(100, 150, 80, 30);
                questionPanel.add(op1);

                String query3 = "select op2 from question where qno='" + i + "' ";
                ResultSet rs3 = stmt.executeQuery(query3);
                rs3.next();
                String res3 = rs3.getString(1);
                op2 = new JLabel();
                op2.setText(res3);
                op2.setVisible(true);
                op2.setBounds(100, 200, 80, 30);
                questionPanel.add(op2);

                String query4 = "select op3 from question where qno='" + i + "' ";
                ResultSet rs4 = stmt.executeQuery(query4);
                rs4.next();
                String res4 = rs4.getString(1);
                op3 = new JLabel();
                op3.setText(res4);
                op3.setVisible(true);
                op3.setBounds(100, 250, 80, 30);
                questionPanel.add(op3);

                String query5 = "select op4 from question where qno='" + i + "' ";
                ResultSet rs5 = stmt.executeQuery(query5);
                rs5.next();
                String res5 = rs5.getString(1);
                op4 = new JLabel();
                op4.setText(res5);
                op4.setVisible(true);
                op4.setBounds(100, 300, 80, 30);
                questionPanel.add(op4);

				
                questionPanel.removeAll();
                questionPanel.add(que);
                questionPanel.add(op1);
                questionPanel.add(op2);
                questionPanel.add(op3);
                questionPanel.add(op4);
                questionPanel.add(quest);
                questionPanel.add(qu1);
                questionPanel.add(qu2);
                questionPanel.add(qu3);
                questionPanel.add(qu4);

                questionPanel.add(answ);
                questionPanel.add(answe);
                questionPanel.add(submit);

                questionPanel.repaint();
				
                if (i >= totalQuestions) {
                    next.setEnabled(false); // Remove next button at last question
                }
            } catch (SQLException e1) {
                e1.printStackTrace();
            }

        }

        if (e.getSource() == submit) {
            try (Connection con = DriverManager.getConnection(mysqlUrl, username, password)) {
                PreparedStatement stmt = con.prepareStatement("INSERT INTO score (username, score) VALUES (?, ?)");
                stmt.setString(1, JOptionPane.showInputDialog("Enter your name:")); // Prompt for username
                stmt.setInt(2, score); // Insert score into database
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(userque1.this,
                        "Your Survey is successfully recorded.\nYour score is " + score + "/" + i,
                        "All the Best",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        setLayout(null);
        setSize(600, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
